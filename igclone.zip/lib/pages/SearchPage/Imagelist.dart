import 'package:flutter/cupertino.dart';

class SearchImageList {
  String images;

  SearchImageList ({@required this.images });
}


final imagelist = [
  SearchImageList(
    images: "image_asset/post/post1.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post2.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post3.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post4.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post5.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post6.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post1.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post2.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post3.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post4.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post5.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post6.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post1.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post2.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post3.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post4.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post5.jpg"
  ),
  SearchImageList(
    images: "image_asset/post/post6.jpg"
  ),
  
];